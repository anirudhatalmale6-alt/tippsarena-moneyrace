PREDICTION VIDEOS - LUXTIPPS
Built 10.09.2026

7 videos, 1080 x 1920, 30 fps, H.264, NO audio track.
Add the sound in the app - that is what the algorithm rewards, and it keeps
somebody else's music out of your ad account.

HOW THE PACK IS PUT TOGETHER
One video per league, one full matchday in each, 35 to 40 seconds. That keeps
every file under the 60-second YouTube Shorts ceiling, so these need no
per-night split the way the Champions League did.

Unchanged since the last pack: no text at the bottom, no bot name, no odds on
screen, no title card, English throughout, kick-off times in German local
time.

WHERE THE SCORELINES COME FROM
Not from me. For every match the bookmakers' EXACT SCORE market is read from
the API. Each price is converted to a probability and normalised per
bookmaker (that strips the margin out), then averaged across the books.

The pick is NOT the most likely score. Even with a clear favourite that is
only an 8-12% shot, and it produces a column of near-identical 1:2s. The pick
is drawn from the scorelines priced between 5.00 and 20.00, with the target
zone rotating down the matchday. The odds no longer appear on screen - they
only decide which line gets published.
  lowest 5.25   highest 19.80   average 11.05

Every scoreline is a line a bookmaker actually offers. Nothing is invented.
LuxTipps and TippsArena never carry the same score for the same match - that
is enforced in code, not left to chance.

The screen says PREDICTION, never FULL TIME. These go out BEFORE kick-off,
and a viewer who reads a prediction as a result will think the account lies
the moment the real score lands.

THE FILES
  luxtipps-prognosen-bundesliga.mp4                      36 s
  luxtipps-prognosen-eredivisie.mp4                      36 s
  luxtipps-prognosen-la-liga.mp4                         39 s
  luxtipps-prognosen-ligue-1.mp4                         36 s
  luxtipps-prognosen-premier-league.mp4                  39 s
  luxtipps-prognosen-primeira-liga.mp4                   36 s
  luxtipps-prognosen-serie-a.mp4                         39 s

MATCHDAYS IN THIS PACK
  Premier League   Matchday 4   10 of 10 matches
  Bundesliga       Matchday 3   9 of 9 matches
  La Liga          Matchday 5   10 of 10 matches
  Serie A          Matchday 4   10 of 10 matches
  Ligue 1          Matchday 4   9 of 9 matches
  Primeira Liga    Matchday 6   9 of 9 matches
  Eredivisie       Matchday 6   9 of 9 matches

MISSING MATCHES
These fixtures have no pre-match market in the API yet (odds usually open 2-3
days before kick-off), so they are not in the videos:
  keine / none

  Say the word when you want them - refetching and re-rendering everything
  takes about 15 minutes.

EVERY TIP IN PLAIN TEXT

Premier League - Matchday 4
Match                                 Tip         Kick-off
Aston Villa - Nottm Forest             3:1         12.09. 16:00
Bournemouth - Brentford                1:1         12.09. 16:00
Chelsea - Hull City                    1:0         12.09. 16:00
Crystal Palace - Ipswich               3:0         12.09. 16:00
Liverpool - Fulham                     2:1         12.09. 16:00
Tottenham - Everton                    2:0         12.09. 18:30
Sunderland - Arsenal                   0:4         12.09. 21:00
Coventry - Brighton                    0:1         13.09. 15:00
Man United - Man City                  2:2         13.09. 17:30
Leeds - Newcastle                      0:2         14.09. 21:00

Bundesliga - Matchday 3
Match                                 Tip         Kick-off
Union Berlin - Schalke                 3:1         11.09. 20:30
Dortmund - Paderborn                   2:0         12.09. 15:30
Hoffenheim - Stuttgart                 2:1         12.09. 15:30
Freiburg - Gladbach                    0:1         12.09. 15:30
Augsburg - Leverkusen                  1:2         12.09. 15:30
Mainz 05 - Frankfurt                   1:0         12.09. 15:30
Köln - Bremen                          0:0         12.09. 18:30
Leipzig - HSV                          1:1         13.09. 15:30
Elversberg - Bayern                    1:3         13.09. 17:30

La Liga - Matchday 5
Match                                 Tip         Kick-off
Sevilla - Valencia                     2:2         11.09. 21:00
Racing - Alaves                        1:1         12.09. 14:00
Osasuna - Espanyol                     1:2         12.09. 16:15
Athletic - Elche                       0:1         12.09. 18:30
Real Madrid - Rayo                     3:0         12.09. 21:00
Celta - Malaga                         3:1         13.09. 14:00
Levante - Barcelona                    2:3         13.09. 16:15
Getafe - Depor                         0:0         13.09. 18:30
Sociedad - Atlético                    2:1         13.09. 21:00
Villarreal - Betis                     3:2         14.09. 21:00

Serie A - Matchday 4
Match                                 Tip         Kick-off
Venezia - Fiorentina                   2:0         11.09. 20:45
Genoa - Frosinone                      1:1         12.09. 15:00
Lazio - Milan                          0:2         12.09. 18:00
Atalanta - Cagliari                    0:1         12.09. 20:45
Lecce - Monza                          1:0         13.09. 15:00
Napoli - Bologna                       3:0         13.09. 18:00
Sassuolo - Juventus                    2:2         13.09. 20:45
Como - Parma                           2:1         14.09. 18:30
Torino - Roma                          0:0         14.09. 18:30
Inter - Udinese                        4:1         14.09. 20:45

Ligue 1 - Matchday 4
Match                                 Tip         Kick-off
Rennes - Marseille                     0:0         11.09. 20:45
Strasbourg - Monaco                    1:1         12.09. 17:15
Auxerre - Nice                         2:1         12.09. 20:45
Le Havre - Angers                      2:2         12.09. 20:45
Lorient - Toulouse                     1:0         12.09. 20:45
Paris FC - Lyon                        1:2         12.09. 20:45
Lille - Troyes                         4:0         13.09. 15:00
Le Mans - Lens                         0:1         13.09. 17:15
Brest - PSG                            0:3         13.09. 20:45

Primeira Liga - Matchday 6
Match                                 Tip         Kick-off
Nacional - Alverca                     1:3         12.09. 16:30
Casa Pia - Porto                       0:2         12.09. 19:00
Academico Viseu - Vitória              1:0         12.09. 21:30
Arouca - Santa Clara                   2:2         13.09. 19:00
Benfica - Gil Vicente                  2:0         13.09. 19:00
Famalicao - Sporting                   0:0         13.09. 21:30
Rio Ave - Estrela                      1:1         14.09. 19:45
Braga - Estoril                        2:1         14.09. 21:15
Moreirense - Maritimo                  0:1         14.09. 21:15

Eredivisie - Matchday 6
Match                                 Tip         Kick-off
AZ - Willem II                         1:1         11.09. 20:00
Twente - Den Haag                      2:0         12.09. 16:30
Go Ahead Eagles - Groningen            1:2         12.09. 18:45
Fortuna - Ajax                         2:2         12.09. 20:00
Cambuur - NEC                          1:3         12.09. 21:00
Excelsior - Utrecht                    1:0         13.09. 12:15
Heerenveen - Telstar                   0:1         13.09. 14:30
Zwolle - Feyenoord                     0:3         13.09. 16:45
PSV - Sparta                           3:1         13.09. 20:00
