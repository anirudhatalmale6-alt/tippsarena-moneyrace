PREDICTION VIDEOS - LUXTIPPS
Built 07.09.2026

4 videos, 1080 x 1920, 30 fps, H.264, NO audio track.
Add the sound in the app - that is what the algorithm rewards, and it keeps
somebody else's music out of your ad account.

HOW THE PACK IS PUT TOGETHER
Where a matchday runs over several evenings you get BOTH cuts: the whole
matchday in one go, plus one video per night. The long cut is for TikTok and
the feed; the short ones are for Shorts (60-second ceiling) and for posting
in the morning exactly the matches that are played that same evening.

The scorelines are identical in both cuts - the selection runs across the
whole matchday, not per night. Otherwise the same fixture would carry a
different tip in the long video and in the short one.

Unchanged since the last pack: no text at the bottom, no bot name, no odds on
screen, no title card, English throughout, kick-off times in German local
time.

WHERE THE SCORELINES COME FROM
Not from me. For every match the bookmakers' EXACT SCORE market is read from
the API. Each price is converted to a probability and normalised per
bookmaker (that strips the margin out), then averaged across the books.

The pick is NOT the most likely score. Even with a clear favourite that is
only an 8-12% shot, and it produces a column of near-identical 1:2s. The pick
is drawn from the scorelines priced between 5.00 and 20.00, with the target
zone rotating down the matchday. The odds no longer appear on screen - they
only decide which line gets published.
  lowest 6.58   highest 17.05   average 11.37

Every scoreline is a line a bookmaker actually offers. Nothing is invented.
LuxTipps and TippsArena never carry the same score for the same match - that
is enforced in code, not left to chance.

The screen says PREDICTION, never FULL TIME. These go out BEFORE kick-off,
and a viewer who reads a prediction as a result will think the account lies
the moment the real score lands.

THE FILES
  luxtipps-prognosen-champions-league-08-09.mp4          25 s
  luxtipps-prognosen-champions-league-09-09.mp4          25 s
  luxtipps-prognosen-champions-league-10-09.mp4          25 s
  luxtipps-prognosen-champions-league.mp4                68 s

MATCHDAYS IN THIS PACK
  Champions League Matchday 1   18 of 18 matches

MISSING MATCHES
These fixtures have no pre-match market in the API yet (odds usually open 2-3
days before kick-off), so they are not in the videos:
  keine / none

  Say the word when you want them - refetching and re-rendering everything
  takes about 15 minutes.

EVERY TIP IN PLAIN TEXT

Champions League - Matchday 1
Match                                 Tip         Kick-off
AEK Athens - LASK                      3:0         08.09. 18:45
Club Brugge - Aston Villa              1:1         08.09. 18:45
Dortmund - Villarreal                  1:0         08.09. 21:00
Real Madrid - Inter                    1:2         08.09. 21:00
Lille - Betis                          2:1         08.09. 21:00
Porto - Man City                       1:3         08.09. 21:00
Stuttgart - Viking                     3:2         09.09. 18:45
Barcelona - Feyenoord                  4:0         09.09. 18:45
PSG - Slovan                           6:0         09.09. 21:00
Liverpool - Atlético                   0:0         09.09. 21:00
Sporting - Galatasaray                 2:0         09.09. 21:00
Napoli - Arsenal                       0:1         09.09. 21:00
Fenerbahçe - Roma                      0:2         10.09. 18:45
PSV - Shakhtar                         3:1         10.09. 18:45
Bayern - Bodo/Glimt                    4:1         10.09. 21:00
Como - Leipzig                         2:2         10.09. 21:00
Man United - Sabah                     5:1         10.09. 21:00
Slavia Praha - Lens                    0:1         10.09. 21:00
